questions = [
    {
        "question": "Bananas should be free.",
        "effect": {
            "econ": 10,
            "dipl": 0,
            "govt": 0,
            "scty": 0
        }
    },
    {
        "question": "If the bananas are free, no one will pick them up.",
        "effect": {
            "econ": -10,
            "dipl": 0,
            "govt": 0,
            "scty": 0
        }
    },
    {
        "question": "Each monkey has to find bananas on its own. ",
        "effect": {
            "econ": -10,
            "dipl": 0,
            "govt": 0,
            "scty": 0
        }
    },
    {
        "question": "The monkeys should become humans.",
        "effect": {
            "econ": 0,
            "dipl": 0,
            "govt": 0,
            "scty": 10
        }
    },
    {
        "question": "Technology bad.",
        "effect": {
            "econ": 0,
            "dipl": 0,
            "govt": 0,
            "scty": -10
        }
    },
    {
        "question": "Monkeys should use spears.",
        "effect": {
            "econ": 0,
            "dipl": 0,
            "govt": 0,
            "scty": 10
        }
    },
    {
        "question": "Monkeys should walk on two legs.",
        "effect": {
            "econ": 0,
            "dipl": 0,
            "govt": 0,
            "scty": 10
        }
    },
    {
        "question": "Rich monkeys should pay taxes.",
        "effect": {
            "econ": 10,
            "dipl": 0,
            "govt": 0,
            "scty": 0
        }
    },
    {
        "question": "Monkeys need a king.",
        "effect": {
            "econ": 0,
            "dipl": 0,
            "govt": -10,
            "scty": 0
        }
    },
    {
        "question": "Monkeys must have equal roles in society.",
        "effect": {
            "econ": 0,
            "dipl": 0,
            "govt": 10,
            "scty": 0
        }
    },
    {
        "question": "Monkeys must live in a society.",
        "effect": {
            "econ": 0,
            "dipl": -10,
            "govt": 0,
            "scty": 0
        }
    },
    {
        "question": "The monkey tribes should compete with each other.",
        "effect": {
            "econ": 0,
            "dipl": -10,
            "govt": 0,
            "scty": 0
        }
    },
    {
        "question": "Monkeys don't need authority. ",
        "effect": {
            "econ": 0,
            "dipl": 0,
            "govt": 10,
            "scty": 0
        }
    },
    {
        "question": "Monkey societies should have their own languages.",
        "effect": {
            "econ": 0,
            "dipl": -10,
            "govt": 0,
            "scty": 5
        }
    },
    {
        "question": "Monkeys should have schools. ",
        "effect": {
            "econ": 0,
            "dipl": 0,
            "govt": 0,
            "scty": 5
        }
    },
    {
        "question": "Monkey societies should be hierarchical.",
        "effect": {
            "econ": 0,
            "dipl": 0,
            "govt": -10,
            "scty": 0
        }
    },
    {
        "question": "From each monkey according to its ability, to each monkey according to its needs.",
        "effect": {
            "econ": 10,
            "dipl": -5,
            "govt": 0,
            "scty": 0
        }
    },
    {
        "question": "Monkeys should live on trees.",
        "effect": {
            "econ": 0,
            "dipl": 0,
            "govt": 0,
            "scty": -10
        }
    }
];
